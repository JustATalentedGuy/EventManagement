package UI;

import users.Organizer;
import events.*;
import eventmanagement.Main;
import system.SystemManager;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.ArrayList;

public class OrganizerPage {

    private Main app;
    private Organizer organizer;
    private VBox rootPane;

    public OrganizerPage(Main app, Organizer organizer) {
        this.app = app;
        this.organizer = organizer;
        createOrganizerPage();
    }

    private void createOrganizerPage() {
        rootPane = new VBox();
        rootPane.setPadding(new Insets(10));
        rootPane.setSpacing(10);
        
        String username = organizer.getUsername() != null ? organizer.getUsername() : "Guest";
        Label titleLabel = new Label("Available Events for " + username);
        
        VBox eventsContainer = new VBox();  // New VBox for events
        eventsContainer.setSpacing(10);      // Space between event cards
        
        ArrayList<Event> events = SystemManager.getAllEvents();  // Simulated events
        events.forEach(event -> {
            VBox eventCard = createEventCard(event);
            eventsContainer.getChildren().add(eventCard); // Add to new VBox
        });
        
        ScrollPane scrollPane = new ScrollPane(eventsContainer); // Set ScrollPane to use eventsContainer
        scrollPane.setFitToWidth(true);

        Button registerButton = new Button("Add Event Request");
        registerButton.setOnAction(e -> app.showNewEventRequestPage(organizer));

        Button goBack = new Button("Log Out");
        goBack.setOnAction(e -> 
            {
                app.showLoginPage();
            }
        );
        
        rootPane.getChildren().addAll(titleLabel, scrollPane, registerButton, goBack);
    }

    private VBox createEventCard(Event event) {
        VBox eventCard = new VBox();
        eventCard.setPadding(new Insets(10));
        eventCard.setStyle("-fx-border-color: black; -fx-border-width: 1;");
        Label eventTitle = new Label(event.getName());
        Label eventDesc = new Label(event.getDescription());
        Label eventDate = new Label("Date: " + event.getStartTime() + " - " + event.getEndTime());

        eventCard.getChildren().addAll(eventTitle, eventDesc, eventDate);
        return eventCard;
    }

    public VBox getRootPane() {
        return rootPane;
    }
}