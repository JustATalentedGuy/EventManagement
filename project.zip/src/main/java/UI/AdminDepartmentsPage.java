package UI;

import java.util.ArrayList;

import eventmanagement.Main;
import users.Admin;
import venue.Department;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import system.SystemManager;

public class AdminDepartmentsPage {

    private Main app;
    private Admin admin;
    private VBox rootPane;

    public AdminDepartmentsPage(Main app, Admin admin) {
        this.app = app;
        this.admin = admin;
        createAdminDepartmentsPage();
    }

    private void createAdminDepartmentsPage() {
        rootPane = new VBox();
        rootPane.setPadding(new Insets(10));
        rootPane.setSpacing(10);

        Label titleLabel = new Label("Manage Departments");

        TextField departmentField = new TextField();
        departmentField.setPromptText("Enter new department name");

        Button addDepartmentButton = new Button("Add Department");

        addDepartmentButton.setOnAction(e -> addNewDepartment(departmentField.getText()));

        // Simulated list of departments
        VBox departmentList = new VBox();
        departmentList.setSpacing(10);
        ArrayList<Department> departments = SystemManager.getAllDepartments();
        for (Department department : departments) {
            departmentList.getChildren().add(new Label(department.getName()));
        }

        ScrollPane scrollPane = new ScrollPane(departmentList);
        scrollPane.setFitToWidth(true);

        Button goBack = new Button("Go Back");
        goBack.setOnAction(e -> 
            {
                app.showAdminPage(admin);;
            }
        );

        rootPane.getChildren().addAll(titleLabel, departmentField, addDepartmentButton, scrollPane, goBack);
    }

    private void addNewDepartment(String departmentName) {
        SystemManager.registerDepartment(departmentName);
    }

    public VBox getRootPane() {
        return rootPane;
    }
}
