package UI;

import system.SystemManager;
import eventmanagement.Main;
import users.*;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

public class LoginPage {
    private Main app;
    private GridPane rootPane;

    public LoginPage(Main app) {
        this.app = app;
        createLoginPage();
    }

    private void createLoginPage() {
        rootPane = new GridPane();
        rootPane.setPadding(new Insets(10));
        rootPane.setHgap(10);
        rootPane.setVgap(10);

        Label userLabel = new Label("Username:");
        TextField userField = new TextField();
        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();

        ComboBox<String> userTypeBox = new ComboBox<>();
        userTypeBox.getItems().addAll("Viewer", "Organizer", "Admin");

        Button loginButton = new Button("Login");

        loginButton.setOnAction(e -> {
            String userType = userTypeBox.getValue();
            String username = userField.getText();
            String password = passField.getText();

            int id = SystemManager.validateUser(username, password, userType);

            if (id != -1) {
                User user = SystemManager.getUser(id);
                if (userType.equals("Viewer")) {
                    app.showViewerPage((Viewer) user);
                } else if (userType.equals("Organizer")) {
                    app.showOrganizerPage((Organizer) user);
                } else if (userType.equals("Admin")) {
                    app.showAdminPage((Admin) user);
                }
            } else {
                showAlert("Login failed", "Invalid username, password, or user type.");
            }
        });

        rootPane.add(userLabel, 0, 0);
        rootPane.add(userField, 1, 0);
        rootPane.add(passLabel, 0, 1);
        rootPane.add(passField, 1, 1);
        rootPane.add(userTypeBox, 1, 2);
        rootPane.add(loginButton, 1, 3);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public GridPane getRootPane() {
        return rootPane;
    }
}
