package UI;

import eventmanagement.Main;
import system.SystemManager;
import users.Viewer;
import events.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.InputStream;
import java.util.ArrayList;

public class ViewerPage {

    private Main app;
    private Viewer viewer;
    private VBox rootPane;

    public ViewerPage(Main app, Viewer viewer) {
        this.app = app;
        this.viewer = viewer;
        createViewerPage();
    }

    private void createViewerPage() {
        rootPane = new VBox();
        rootPane.setPadding(new Insets(10));
        rootPane.setSpacing(10);

        String username = viewer.getUsername() != null ? viewer.getUsername() : "Guest";
        Label titleLabel = new Label("Available Events for " + username);

        // Create an HBox for the username and icon
        HBox userInfoContainer = new HBox();
        userInfoContainer.setAlignment(Pos.TOP_RIGHT); // Align to top right
        userInfoContainer.setSpacing(5); // Space between icon and username

        // Create the username label
        Label userNameLabel = new Label(username);

        // Load the account icon image using relative path
        InputStream inputStream = getClass().getResourceAsStream("/assets/account_icon.jpg");
        if (inputStream == null) {
            System.out.println("Image not found! Check the path.");
            userInfoContainer.getChildren().add(userNameLabel);
        } else {
            Image personIcon = new Image(inputStream);
            ImageView iconView = new ImageView(personIcon);
            iconView.setFitWidth(20); // Set width of icon
            iconView.setFitHeight(20); // Set height of icon
            userInfoContainer.getChildren().addAll(iconView, userNameLabel);
        }

        VBox eventsContainer = new VBox(); // New VBox for events
        eventsContainer.setSpacing(10); // Space between event cards

        ArrayList<Event> events = SystemManager.getAllEvents(); // Simulated events
        events.forEach(event -> {
            VBox eventCard = createEventCard(event);
            eventsContainer.getChildren().add(eventCard); // Add to new VBox
        });

        Button goBack = new Button("Log Out");
        goBack.setOnAction(e -> 
            {
                app.showLoginPage();
            }
        );

        ScrollPane scrollPane = new ScrollPane(eventsContainer); // Set ScrollPane to use eventsContainer
        scrollPane.setFitToWidth(true);

        // Add user info container and the rest of the UI to the root pane
        rootPane.getChildren().addAll(userInfoContainer, titleLabel, scrollPane, goBack);
    }

    private VBox createEventCard(Event event) {
        VBox eventCard = new VBox();
        eventCard.setPadding(new Insets(10));
        eventCard.setStyle("-fx-border-color: black; -fx-border-width: 1;");
        Label eventTitle = new Label(event.getName());
        Label eventDesc = new Label(event.getDescription());
        Label eventDate = new Label("Date: " + event.getStartTime() + " - " + event.getEndTime());

        Button registerButton = new Button("Register");
        registerButton.setOnAction(e -> registerForEvent(event));

        eventCard.getChildren().addAll(eventTitle, eventDesc, eventDate, registerButton);
        return eventCard;
    }

    private void registerForEvent(Event event) {
        // Logic to register the viewer for the selected event
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Registration");
        alert.setHeaderText("Registration Successful");
        alert.setContentText("You have successfully registered for " + event.getName());
        alert.showAndWait();
    }

    public VBox getRootPane() {
        return rootPane;
    }
}
