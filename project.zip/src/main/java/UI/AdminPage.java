package UI;

import events.*;
import java.util.ArrayList;
import eventmanagement.Main;
import users.Admin;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import system.SystemManager;

public class AdminPage {

    private Main app;
    private Admin admin;
    private VBox rootPane;

    public AdminPage(Main app, Admin admin) {
        this.app = app;
        this.admin = admin;
        createAdminPage();
    }

    private void createAdminPage() {
        rootPane = new VBox();
        rootPane.setPadding(new Insets(10));
        rootPane.setSpacing(10);

        Label titleLabel = new Label("Admin Dashboard - Event Approval Requests");

        // Simulated event requests
        VBox approvalRequests = createApprovalRequestCards();

        ScrollPane scrollPane = new ScrollPane(approvalRequests);
        scrollPane.setFitToWidth(true);

        Button manageDepartmentsButton = new Button("Manage Departments");
        manageDepartmentsButton.setOnAction(e -> app.showManageDepartmentsPage(admin));

        Button manageVenuesButton = new Button("Manage Venues");
        manageVenuesButton.setOnAction(e -> app.showManageVenuesPage(admin));

        Button goBack = new Button("Log Out");
        goBack.setOnAction(e -> 
            {
                app.showLoginPage();
            }
        );

        rootPane.getChildren().addAll(titleLabel, scrollPane, manageDepartmentsButton, manageVenuesButton, goBack);
    }

    private VBox createApprovalRequestCards() {
        VBox requestsBox = new VBox();
        requestsBox.setSpacing(10);
        ArrayList<Event> requests = SystemManager.getListOfOrganizingRequests();

        // Simulated event approval requests
        for (Event req : requests) {
            VBox requestCard = new VBox();
            requestCard.setPadding(new Insets(10));
            requestCard.setStyle("-fx-border-color: black; -fx-border-width: 1;");
            Label requestLabel = new Label(req.getName());
            Label organizerLabel = new Label(req.getOrganizer().getUsername());
            Label departmentLabel = new Label(req.getDepartment().getName());
            Label venueLabel = new Label(req.getVenue().getName());
    
            Button approveButton = new Button("Approve");
            Button rejectButton = new Button("Reject");
    
            approveButton.setOnAction(e -> admin.acceptOrganizingRequest(req));
            rejectButton.setOnAction(e -> admin.declineOrganizingRequest(req));
    
            requestCard.getChildren().addAll(requestLabel, organizerLabel, departmentLabel, venueLabel, approveButton, rejectButton);
            requestsBox.getChildren().add(requestCard);
        }
        return requestsBox;
    }

    public VBox getRootPane() {
        return rootPane;
    }
}
