package UI;

import java.util.ArrayList;

import eventmanagement.Main;
import users.Admin;
import venue.Venue;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import system.SystemManager;

public class AdminVenuesPage {

    private Main app;
    private Admin admin;
    private VBox rootPane;

    public AdminVenuesPage(Main app, Admin admin) {
        this.app = app;
        this.admin = admin;
        createAdminVenuesPage();
    }

    private void createAdminVenuesPage() {
        rootPane = new VBox();
        rootPane.setPadding(new Insets(10));
        rootPane.setSpacing(10);

        Label titleLabel = new Label("Manage Venues");

        TextField venueField = new TextField();
        venueField.setPromptText("Enter new venue name");

        Button addVenueButton = new Button("Add Venue");

        addVenueButton.setOnAction(e -> addNewVenue(venueField.getText()));

        VBox venueList = new VBox();
        venueList.setSpacing(10);
        ArrayList<Venue> venues = SystemManager.getAllVenues();
        for (Venue venue : venues) {
            venueList.getChildren().add(new Label(venue.getName()));
        }

        ScrollPane scrollPane = new ScrollPane(venueList);
        scrollPane.setFitToWidth(true);

        Button goBack = new Button("Go Back");
        goBack.setOnAction(e -> 
            {
                app.showAdminPage(admin);;
            }
        );

        rootPane.getChildren().addAll(titleLabel, venueField, addVenueButton, scrollPane, goBack);
    }

    private void addNewVenue(String venueName) {
        SystemManager.registerVenue(venueName);
    }

    public VBox getRootPane() {
        return rootPane;
    }
}
