package UI;

import eventmanagement.Main;
import users.Organizer;
import venue.*;

import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.scene.layout.VBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import system.SystemManager;

public class NewEventRequestPage {

    private Main app;
    private Organizer organizer;
    private VBox rootPane;

    // Fields for event-specific input
    private TextField prizeAmountField;         // For Competition
    private TextField competitionTypeField;     // For Competition
    private TextField speakerNameField;         // For Seminar
    private TextField topicNameField;           // For Seminar
    private TextField trainerNameField;         // For Workshop
    private TextArea materialsProvidedField;    // For Workshop

    // Containers for event-specific fields
    private VBox eventSpecificFields;

    public NewEventRequestPage(Main app, Organizer organizer) {
        this.app = app;
        this.organizer = organizer;
        createNewEventRequestPage();
    }
    
    private void createNewEventRequestPage() {
        rootPane = new VBox();
        rootPane.setPadding(new Insets(10));
        rootPane.setSpacing(10);
    
        Label titleLabel = new Label("Request to Organize New Event");
    
        TextField eventNameField = new TextField();
        eventNameField.setPromptText("Event Name");
    
        TextArea eventDescField = new TextArea();
        eventDescField.setPromptText("Event Description");
    
        ComboBox<String> eventVenueBox = new ComboBox<>();
        eventVenueBox.getItems().addAll(getAllVenueStrings());
        eventVenueBox.setPromptText("Select Venue");
    
        ComboBox<String> eventDepartmentBox = new ComboBox<>();
        eventDepartmentBox.getItems().addAll(getAllDepartmentStrings());
        eventDepartmentBox.setPromptText("Select Department");

        TextField maxParticipantsField = new TextField();
        maxParticipantsField.setPromptText("Maximum Participants");
    
        // DatePicker for Start and End Dates
        DatePicker startDatePicker = new DatePicker();
        startDatePicker.setPromptText("Select Start Date");
    
        DatePicker endDatePicker = new DatePicker();
        endDatePicker.setPromptText("Select End Date");
    
        // ComboBox for Start and End Times
        ComboBox<String> startTimeBox = new ComboBox<>();
        ComboBox<String> endTimeBox = new ComboBox<>();
    
        startTimeBox.getItems().addAll(getTimeOptions());
        endTimeBox.getItems().addAll(getTimeOptions());
    
        startTimeBox.setPromptText("Select Start Time");
        endTimeBox.setPromptText("Select End Time");
    
        // ToggleGroup for Online or Offline selection
        ToggleGroup onlineOfflineToggleGroup = new ToggleGroup();
    
        RadioButton onlineRadioButton = new RadioButton("Online");
        onlineRadioButton.setToggleGroup(onlineOfflineToggleGroup);
        onlineRadioButton.setSelected(true);  // Default to Online
    
        RadioButton offlineRadioButton = new RadioButton("Offline");
        offlineRadioButton.setToggleGroup(onlineOfflineToggleGroup);
    
        // Adding a label for Online/Offline toggle
        Label onlineOfflineLabel = new Label("Event Type:");

        // ComboBox for event type selection
        ComboBox<String> eventTypeBox = new ComboBox<>();
        eventTypeBox.getItems().addAll("Competition", "Seminar", "Workshop");
        eventTypeBox.setPromptText("Select Event Type");

        // Initialize the VBox for event-specific fields
        eventSpecificFields = new VBox();
        eventSpecificFields.setSpacing(5);
        eventSpecificFields.setVisible(false); // Hide initially

        // Listen for event type changes and show corresponding fields
        eventTypeBox.setOnAction(e -> {
            String selectedEventType = eventTypeBox.getValue();
            eventSpecificFields.getChildren().clear(); // Clear previous fields
            switch (selectedEventType) {
                case "Competition":
                    eventSpecificFields.getChildren().addAll(createCompetitionFields());
                    break;
                case "Seminar":
                    eventSpecificFields.getChildren().addAll(createSeminarFields());
                    break;
                case "Workshop":
                    eventSpecificFields.getChildren().addAll(createWorkshopFields());
                    break;
            }
            eventSpecificFields.setVisible(true); // Show the fields after selection
        });

        Button submitButton = new Button("Submit Request");
    
        // On submit, combine Date and Time for both start and end times
        submitButton.setOnAction(e -> {
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();
            String startTime = startTimeBox.getValue();
            String endTime = endTimeBox.getValue();
            boolean online = onlineRadioButton.isSelected(); 
            String field1 = null, field2 = null;
    
            if (startDate != null && endDate != null && startTime != null && endTime != null) {
                String startDateTime = startDate.toString() + " " + startTime;
                String endDateTime = endDate.toString() + " " + endTime;

                // Retrieve event-specific inputs based on event type
                if ("Competition".equals(eventTypeBox.getValue())) {
                    field1 = prizeAmountField.getText();
                    field2 = competitionTypeField.getText();
                    // Add logic to process competition event
                } else if ("Seminar".equals(eventTypeBox.getValue())) {
                    field1 = speakerNameField.getText();
                    field2 = topicNameField.getText();
                    // Add logic to process seminar event
                } else if ("Workshop".equals(eventTypeBox.getValue())) {
                    field1 = trainerNameField.getText();
                    field2 = materialsProvidedField.getText();
                    // Add logic to process workshop event
                }

                // Process the event request
                submitEventRequest(eventNameField.getText(), eventDescField.getText(), eventVenueBox.getValue(),
                        eventDepartmentBox.getValue(), organizer.getUserID(), startDateTime, endDateTime, Integer.parseInt(maxParticipantsField.getText()), online, field1, field2, eventTypeBox.getValue());
            } else {
                // Handle missing date or time selections
                System.out.println("Please select both start and end dates and times.");
            }
        });
    
        Button goBack = new Button("Go Back");
        goBack.setOnAction(e -> app.showOrganizerPage(organizer));
        
        // Add all components to the UI
        rootPane.getChildren().addAll(titleLabel, eventNameField, eventDescField, eventVenueBox, eventDepartmentBox,
                startDatePicker, startTimeBox, endDatePicker, endTimeBox, onlineOfflineLabel, onlineRadioButton, offlineRadioButton,
                eventTypeBox, eventSpecificFields, submitButton, goBack);
        ScrollPane scrollPane = new ScrollPane(rootPane);
        scrollPane.setFitToWidth(true);
    }

    // Create fields for competition
    private VBox createCompetitionFields() {
        VBox competitionBox = new VBox();
        competitionBox.setSpacing(5);

        Label prizeAmountLabel = new Label("Prize Amount:");
        prizeAmountField = new TextField();
        prizeAmountField.setPromptText("Enter Prize Amount");

        Label competitionTypeLabel = new Label("Competition Type:");
        competitionTypeField = new TextField();
        competitionTypeField.setPromptText("Enter Competition Type");

        competitionBox.getChildren().addAll(prizeAmountLabel, prizeAmountField, competitionTypeLabel, competitionTypeField);
        return competitionBox;
    }

    // Create fields for seminar
    private VBox createSeminarFields() {
        VBox seminarBox = new VBox();
        seminarBox.setSpacing(5);

        Label speakerNameLabel = new Label("Speaker Name:");
        speakerNameField = new TextField();
        speakerNameField.setPromptText("Enter Speaker Name");

        Label topicNameLabel = new Label("Topic Name:");
        topicNameField = new TextField();
        topicNameField.setPromptText("Enter Topic Name");

        seminarBox.getChildren().addAll(speakerNameLabel, speakerNameField, topicNameLabel, topicNameField);
        return seminarBox;
    }

    // Create fields for workshop
    private VBox createWorkshopFields() {
        VBox workshopBox = new VBox();
        workshopBox.setSpacing(5);

        Label trainerNameLabel = new Label("Trainer Name:");
        trainerNameField = new TextField();
        trainerNameField.setPromptText("Enter Trainer Name");

        Label materialsProvidedLabel = new Label("Materials Provided:");
        materialsProvidedField = new TextArea();
        materialsProvidedField.setPromptText("Enter Materials Provided");

        workshopBox.getChildren().addAll(trainerNameLabel, trainerNameField, materialsProvidedLabel, materialsProvidedField);
        return workshopBox;
    }
    
    // Function to get time options in "HH:MM" format
    private ObservableList<String> getTimeOptions() {
        ObservableList<String> timeOptions = FXCollections.observableArrayList();
        for (int hour = 8; hour <= 22; hour++) {
            timeOptions.add(String.format("%02d:00", hour));  // HH:00
            timeOptions.add(String.format("%02d:30", hour));  // HH:30
        }
        return timeOptions;
    }
    
    private void submitEventRequest(String eventName, String eventDescription, String venueName, String departmentName, int organizerID, String startTime, String endTime, int maxParticipants, boolean isOnline, String field1, String field2, String eventType) {
        int venueID = SystemManager.getVenue(venueName).getVenueID();
        int departmentID = SystemManager.getDepartment(departmentName).getDepartmentID();
        SystemManager.createEvent(eventName, eventDescription, venueID, departmentID, organizerID, startTime, endTime, maxParticipants, isOnline, false, false, eventType, field1, field2);
    }

    private ArrayList<String> getAllVenueStrings() {
        ArrayList<String> venueStrings = new ArrayList<>();
        for (Venue venue : SystemManager.getAllVenues()) {
            venueStrings.add(venue.toString());
        }
        return venueStrings;
    }

    private ArrayList<String> getAllDepartmentStrings() {
        ArrayList<String> departmentStrings = new ArrayList<>();
        for (Department department : SystemManager.getAllDepartments()) {
            departmentStrings.add(department.toString());
        }
        return departmentStrings;
    }

    public VBox getRootPane() {
        return rootPane;
    }
}